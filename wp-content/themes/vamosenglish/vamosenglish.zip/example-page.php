<?php 
/*
	Template Name: Example
*/
?>

<? get_header(); ?>
<main>
	<h1>Example</h1>
</main>
<? get_footer(); ?>