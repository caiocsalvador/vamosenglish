<form action="<?=home_url('/')?>">
	<input type="search" class="form-control" placeholder="Search" valuer="<?=get_search_query() ?>" name="s" title="Search">
	<button type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>