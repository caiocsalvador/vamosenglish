<div class="post animated a-down">
    <h3><a href="<? the_permalink(); ?>"><? the_title(); ?></a></h3>    
    <p><a href="<? the_permalink(); ?>"><?=excerpt(40) ?></a></p>
    <div class="cont-link-post d-flex justify-content-between">
        <a href="<? the_permalink(); ?>" class="link-post">Lee mas</a>      
    </div>
</div>