<h3>GALLERY: <?php the_title(); ?></h3>
<a href="#"><?php the_content(); ?></a>