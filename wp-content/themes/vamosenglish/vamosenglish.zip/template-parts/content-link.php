<h3><?php the_title(); ?></h3>
<a href="#"><?php the_content(); ?></a>