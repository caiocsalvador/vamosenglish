<? get_header(); ?>
<h1>Page not found</h1>
<?php the_widget('WP_Widget_Recent_Posts') ?>
<? get_footer(); ?>