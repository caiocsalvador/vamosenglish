<aside>
	<?php dynamic_sidebar('blog-sidebar'); ?>
</aside>