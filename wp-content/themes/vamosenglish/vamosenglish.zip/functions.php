<?php 

require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/theme-support.php';
require get_template_directory() . '/inc/custom-functions.php';
require get_template_directory() . '/inc/custom-types-taxonomy.php';

?>